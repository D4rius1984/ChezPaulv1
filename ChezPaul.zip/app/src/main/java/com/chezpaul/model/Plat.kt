package com.chezpaul.model

data class Plat(
    val nom: String,
    val contientRavigote: Boolean = false
)
